# 💎 DLuz Digital — Sistema Mestre de Prompts da Identidade Visual

Este documento consolida o **DNA Visual Oficial da DLuz Digital** (baseado no logotipo oficial **Infinity Loop** aprovado) e fornece os prompts calibrados para você gerar qualquer material (banners, posts, mockups, cenários, wallpapers e vídeos) com consistência visual de 100%.

---

## 🧬 1. O DNA Visual da Marca (Brand DNA)

- **Símbolo Principal:** Monograma 3D *Infinity Loop* (laço infinito) entrelaçando organicamente as letras **D** e **L**.
- **Materiais & Acabamento:** Vidro fosco translúcido (*frosted glass*) com brilho interno neon ciano + aro externo em titânio aeroespacial escovado com reflexos e lapidação em ouro champanhe nobre.
- **Paleta de Cores:**
  - **Ciano Elétrico / Neon Cyan:** `#00E5FF` / `#22D3EE` (tecnologia, agilidade, circuitos).
  - **Azul Cobalto Profundo:** `#1E3A8A` / `#2563EB` (profundidade, segurança).
  - **Ouro Champanhe / Âmbar:** `#FFB800` / `#F59E0B` (luz, prestígio, autoridade).
  - **Preto Obsidiana / Grafite Escuro:** `#07090E` / `#0B101D` (sofisticação, contraste).
- **Estética & Iluminação:** Luxo corporativo moderno (*Apple Keynote meets Porsche Design*), iluminação de contorno volumétrica (*rim lighting*), renderização em 8K, reflexos suaves e sombras calculadas.

---

## 🎯 2. Os Prompts Mestres Prontos para Uso

### 📌 Prompt 1: A Logo Oficial Infinity Loop (Isolada em Alta Definição)
> **Uso:** Gerar a marca principal em 3D realista para novos ângulos, materiais ou resoluções extremas.

```text
An ultra-premium minimalist 3D emblem logo for technology and marketing company 'DLuz Digital'. The logo mark is a sleek, continuous geometric infinity loop seamlessly morphing the letters 'D' and 'L'. The outer structure is made of brushed aerospace titanium with chamfered bevels, while the inner ribbon is made of frosted luminous cyan and cobalt blue glass glowing with internal light, accented by a warm champagne-gold rim reflection along the upper edge. Perfectly centered on a dark obsidian graphite matte background with subtle ambient studio lighting, soft realistic contact shadows, ray-traced subsurface scattering, elegant Apple-inspired tech aesthetics, 8k resolution, clean composition, no watermarks, no distorted text.
```

---

### 📱 Prompt 2: Mockup de Redes Sociais & Automação (Post / Banner de Vendas)
> **Uso:** Criar imagens de impacto para anúncios no Instagram, posts de carrossel ou banners do site mostrando o poder da automação.

```text
A cinematic high-tech advertising visual for 'DLuz Digital' social media marketing and WhatsApp automation. A sleek modern flagship smartphone floats at a dynamic 30-degree angle against an obsidian slate background with volumetric electric cyan and warm amber neon light trails. On the phone screen, an intuitive glowing interface shows automated WhatsApp chat notifications and high-engagement Instagram Reels metrics with '+315% leads'. Next to the phone, a small holographic 3D Infinity Loop logo of DLuz Digital hovers, glowing in vibrant electric cyan and gold. Premium studio depth of field, hyperrealistic glass reflections, 8k resolution, commercial grade advertising photography.
```

---

### 🏢 Prompt 3: Parede de Escritório Executivo (Fachada / Recepção de Luxo)
> **Uso:** Banners de topo de site, LinkedIn, apresentações institucionais e propostas B2B.

```text
A luxury corporate reception wall of high-tech agency 'DLuz Digital'. A dark fluted marble and brushed matte charcoal wall with architectural downlights. Mounted in the center is an illuminated 3D metal and glass sign: the iconic DLuz Digital Infinity Loop emblem glowing with electric cyan backlit halo lighting, crafted with brushed titanium and gold edges. Below the emblem, the metallic typography 'DLUZ DIGITAL' with the subtitle 'REDES SOCIAIS • AUTOMAÇÃO • IA' in refined illuminated stainless steel. Photorealistic interior architectural photography, elegant high-end executive atmosphere, sharp focus, 8k.
```

---

### 💻 Prompt 4: Wallpaper / Backdrop Abstrato da Marca (16:9)
> **Uso:** Fundo para vídeos no YouTube, apresentações em slides ou fundo de tela.

```text
An ultra-modern abstract 8K brand backdrop for 'DLuz Digital'. Flowing ribbons of luminous electric cyan, deep sapphire blue, and subtle ribbons of molten champagne gold curving smoothly in dark space. Sleek obsidian carbon fiber textures and dark glass geometric planes in the background. Soft cyan ambient fog, cinematic volumetric lighting, elegant tech wave patterns, ultra-clean composition, zero text, minimal luxury aesthetic, 16:9 aspect ratio, Unreal Engine 5 render quality.
```

---

### 👥 Prompt 5: O Fundador (Duilio Luz) com a Identidade da DLuz Digital
> **Uso:** Fotos de perfil institucional, página "Sobre", criativos autorais de autoridade.

```text
A cinematic executive portrait of founder Duilio Luz in a modern high-rise tech agency office at dusk. He is wearing a tailored navy blazer and crisp white shirt, confident and approachable expression, sharp styling, trimmed goatee. In the background through floor-to-ceiling glass windows, a modern city skyline with soft bokeh lights. Integrated subtly on the glass wall behind him is the glowing 3D DLuz Digital Infinity Loop emblem in electric cyan and champagne gold. Hasselblad studio portrait lighting, subtle cyan and warm gold rim lighting catching his shoulders, photorealistic skin textures, 8k resolution.
```

---

### 🤖 Prompt 6: Mascote Frya Executiva com a Marca DLuz Digital
> **Uso:** Vídeos promocionais, assistente de IA, postagens sobre o Atendente Inteligente 24/7.

```text
Cinematic 3D character render of Frya, the official AI partner of DLuz Digital, in Pixar/Riot Games high-fidelity animation style. She has big expressive amber-gold eyes and sleek silver-white hair with subtle neon red and yellow cyber-energy highlights. She is wearing an executive tailored scarlet-red blazer with champagne-gold lapels. She is gracefully gesturing toward a small floating holographic 3D Infinity Loop emblem glowing in electric cyan and gold beside her. Modern glass office environment, warm ambient rim lighting, crisp 8k render, professional, friendly and intelligent presence.
```

---

## 🛠️ 3. Como Customizar os Prompts para Qualquer Ferramenta

| Parâmetro | Palavras-Chave Recomendadas | Efeito Gerado |
| :--- | :--- | :--- |
| **Cores Primárias** | `electric cyan`, `neon cyan`, `cobalt blue`, `champagne gold` | Garante fidelidade exata à paleta da DLuz Digital. |
| **Materiais** | `frosted glass`, `brushed aerospace titanium`, `subsurface scattering` | Dá o acabamento de vidro brilhante com bordas metálicas. |
| **Iluminação** | `volumetric rim lighting`, `cyan halo backlit`, `contact shadows` | Cria o efeito 3D que "salta da tela" no feed escuro. |
| **Negativos / Evitar** | `ugly, blurry, lowres, distorted letters, oversaturated, cheap plastic` | Evita artefatos ou acabamento infantil/plástico. |
